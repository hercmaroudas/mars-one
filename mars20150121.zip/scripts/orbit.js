var mars = null;
var ox, oy = 0;

$(document).ready(function() {
	
	redraw();

});


function redraw() {
    var marsSystem = $('.marsSystem:first');
    
    var orbit = $('.orbit');
    var centerX = Math.round(640 / 2);
    var centerY = Math.round(280 / 2);
    var radiusX = Math.round((640 - 50) / 2);
    var radiusY = Math.round((280 - 40) / 2);
    //console.log('orbit.width()=' + orbit.width() + ', orbit.height()=' + orbit.height());
    //console.log('centerX=' + centerX + ',centerY=' + centerY + ' radiusX=' + radiusX + ', radiusY=' + radiusY);
    var paper = Raphael($('.orbit')[0], 640, 280);
    var ellipse = paper.ellipse(centerX, centerY, radiusX, radiusY);
    ellipse.attr('stroke', '#C0C0C0');
    
    var sun = paper.circle(centerX, centerY, 25)
    
    sun.attr('fill','whiteSmoke');
    sun.attr('stroke', 'whiteSmoke');
	sun.glow({opacity: 1.0, color: "#FFD700", width: 10});
    
	mars = paper.circle(centerX + radiusX, centerY - 7, 15);
	mars.attr('stroke', 'red');
	mars.attr('fill','red');
	mars.drag(dragMove, dragStart, dragStop);
	ox = mars.x;
	oy = mars.y;
	
};

function dragStart() {
		if(mars) {
			ox = mars.x;
			oy = mars.y;
		}
		console.log('dragStart, ox=' + ox + ', oy=' + oy);
	}
	
	function dragMove(dx, dy, x, y, elem) {
		console.log('dx='+ dx +', dy='+dy+', x='+x+', y='+y+', elem='+elem);
		if(mars) {
			ox += dx;
			oy += dy;
			mars.attr({
				x: x,
				y: y
			});
		}
	}
	
	function dragStop() {
		console.log('dragStop');
	}